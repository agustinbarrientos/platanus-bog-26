/* @ds-bundle: {"format":4,"namespace":"EvaraHealthDesignSystem_a5caa1","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"BottomSheet","sourcePath":"components/feedback/BottomSheet.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Notice","sourcePath":"components/feedback/Notice.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"RangeSlider","sourcePath":"components/forms/RangeSlider.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"BigStat","sourcePath":"components/health/BigStat.jsx"},{"name":"InsightCard","sourcePath":"components/health/InsightCard.jsx"},{"name":"MascotStage","sourcePath":"components/health/MascotStage.jsx"},{"name":"ProgressRing","sourcePath":"components/health/ProgressRing.jsx"},{"name":"RiskMeter","sourcePath":"components/health/RiskMeter.jsx"},{"name":"TrendSpark","sourcePath":"components/health/TrendSpark.jsx"},{"name":"BottomNav","sourcePath":"components/navigation/BottomNav.jsx"},{"name":"ListRow","sourcePath":"components/navigation/ListRow.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"TopAppBar","sourcePath":"components/navigation/TopAppBar.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"628cebe6205a","components/core/Button.jsx":"3c84b2788d07","components/core/Card.jsx":"6de136fb1674","components/core/Icon.jsx":"ad13db02bc9c","components/core/IconButton.jsx":"402037d916b3","components/core/Tag.jsx":"9150ac33f57d","components/feedback/BottomSheet.jsx":"0925ba5fdc52","components/feedback/Dialog.jsx":"acdfc18de73d","components/feedback/Notice.jsx":"4adbf6aefe63","components/feedback/Toast.jsx":"1a544713b7be","components/feedback/Tooltip.jsx":"55fd384b44da","components/forms/Checkbox.jsx":"64bfb1b5d35d","components/forms/Input.jsx":"18e4e1d50eab","components/forms/Radio.jsx":"404b80b5d8d8","components/forms/RangeSlider.jsx":"eb7b350db7eb","components/forms/Select.jsx":"fa4933329e92","components/forms/Switch.jsx":"b5129cb94297","components/health/BigStat.jsx":"c2ef8b20367a","components/health/InsightCard.jsx":"8076d320e80d","components/health/MascotStage.jsx":"735c426c445f","components/health/ProgressRing.jsx":"e734d01eebf7","components/health/RiskMeter.jsx":"58b358beae56","components/health/TrendSpark.jsx":"e9d6d736b423","components/navigation/BottomNav.jsx":"1d3959a7c541","components/navigation/ListRow.jsx":"aecb1fb1db95","components/navigation/Tabs.jsx":"e59ba4a1b918","components/navigation/TopAppBar.jsx":"6e1334909f22","ui_kits/android_app/App.jsx":"610dafedc5f7","ui_kits/android_app/HabitsScreen.jsx":"3393441b734b","ui_kits/android_app/Onboarding.jsx":"273e49e4a322","ui_kits/android_app/OutlookScreen.jsx":"22e8d344e4f4","ui_kits/android_app/SimulateScreen.jsx":"9696618007b3","ui_kits/android_app/TodayScreen.jsx":"96dd585b85c6","ui_kits/android_app/YouScreen.jsx":"5c94886a8023"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.EvaraHealthDesignSystem_a5caa1 = window.EvaraHealthDesignSystem_a5caa1 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const moiraiCardTone = {
  plain: {
    bg: 'var(--surface-card)',
    border: 'var(--border-subtle)'
  },
  brand: {
    bg: 'var(--surface-brand-soft)',
    border: 'var(--border-brand)'
  },
  good: {
    bg: 'var(--surface-good-soft)',
    border: 'var(--mint-100)'
  },
  watch: {
    bg: 'var(--surface-watch-soft)',
    border: 'var(--amber-100)'
  },
  high: {
    bg: 'var(--surface-high-soft)',
    border: 'var(--clay-100)'
  },
  sunken: {
    bg: 'var(--surface-sunken)',
    border: 'transparent'
  },
  gradient: {
    bg: 'var(--gradient-good)',
    border: 'var(--mint-100)'
  }
};
function Card({
  tone = 'plain',
  elevation = 1,
  padding = 'default',
  onClick,
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const t = moiraiCardTone[tone] || moiraiCardTone.plain;
  const pad = padding === 'none' ? 0 : padding === 'tight' ? 'var(--gutter-card-tight)' : padding === 'roomy' ? 'var(--space-7)' : 'var(--gutter-card)';
  const shadow = ['var(--shadow-0)', 'var(--shadow-1)', 'var(--shadow-2)', 'var(--shadow-3)'][elevation] || 'var(--shadow-1)';
  const tappable = typeof onClick === 'function';
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onPointerDown: () => tappable && setPress(true),
    onPointerUp: () => setPress(false),
    style: {
      background: t.bg,
      border: `1px solid ${t.border}`,
      borderRadius: 'var(--radius-card)',
      padding: pad,
      boxShadow: tappable && hover ? 'var(--shadow-2)' : shadow,
      transform: press ? 'scale(var(--press-scale-card))' : 'scale(1)',
      transition: 'var(--transition-control)',
      cursor: tappable ? 'pointer' : 'default',
      WebkitTapHighlightColor: 'transparent',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Wrapper around the Lucide icon set (CDN). Lucide is the substituted icon system:
   rounded caps + 2px stroke match Moirai's friendly geometry. Host page must load
   https://unpkg.com/lucide@0.469.0/dist/umd/lucide.min.js */
function Icon({
  name = 'heart',
  size = 24,
  strokeWidth = 2,
  color = 'currentColor',
  style,
  ...rest
}) {
  const host = React.useRef(null);
  React.useEffect(() => {
    const el = host.current;
    if (!el) return;
    const draw = () => {
      const lucide = window.lucide;
      if (!lucide) return false;
      el.innerHTML = '';
      const slot = document.createElement('i');
      slot.setAttribute('data-lucide', name);
      el.appendChild(slot);
      try {
        lucide.createIcons({
          nameAttr: 'data-lucide'
        });
      } catch (e) {
        return false;
      }
      const svg = el.querySelector('svg');
      if (svg) {
        svg.setAttribute('width', size);
        svg.setAttribute('height', size);
        svg.setAttribute('stroke-width', strokeWidth);
        svg.style.display = 'block';
      }
      return true;
    };
    if (!draw()) {
      const t = setInterval(() => {
        if (draw()) clearInterval(t);
      }, 120);
      return () => clearInterval(t);
    }
  }, [name, size, strokeWidth]);
  return /*#__PURE__*/React.createElement("span", _extends({
    ref: host,
    "aria-hidden": "true",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: size,
      height: size,
      color,
      flex: '0 0 auto',
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const moiraiBadgeTone = {
  neutral: {
    bg: 'var(--n-100)',
    fg: 'var(--text-body)'
  },
  brand: {
    bg: 'var(--sky-100)',
    fg: 'var(--sky-700)'
  },
  good: {
    bg: 'var(--mint-100)',
    fg: 'var(--mint-700)'
  },
  watch: {
    bg: 'var(--amber-100)',
    fg: 'var(--amber-700)'
  },
  high: {
    bg: 'var(--clay-100)',
    fg: 'var(--clay-700)'
  },
  solid: {
    bg: 'var(--sky-500)',
    fg: 'var(--text-on-brand)'
  }
};
function Badge({
  tone = 'neutral',
  icon,
  size = 'md',
  children,
  style,
  ...rest
}) {
  const t = moiraiBadgeTone[tone] || moiraiBadgeTone.neutral;
  const sm = size === 'sm';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: sm ? '4px' : '6px',
      padding: sm ? '3px 8px' : '5px 12px',
      background: t.bg,
      color: t.fg,
      borderRadius: 'var(--radius-pill)',
      font: `var(--weight-bold) ${sm ? '11px' : '13px'}/1.2 var(--font-text)`,
      letterSpacing: 'var(--track-label)',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: sm ? 12 : 14,
    strokeWidth: 2.5
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const moiraiButtonTone = {
  primary: {
    bg: 'var(--sky-500)',
    bgHover: 'var(--sky-600)',
    fg: 'var(--text-on-brand)',
    shadow: 'var(--shadow-brand)',
    border: 'transparent'
  },
  good: {
    bg: 'var(--mint-500)',
    bgHover: 'var(--mint-600)',
    fg: 'var(--text-on-brand)',
    shadow: 'var(--shadow-good)',
    border: 'transparent'
  },
  secondary: {
    bg: 'var(--sky-50)',
    bgHover: 'var(--sky-100)',
    fg: 'var(--sky-700)',
    shadow: 'none',
    border: 'var(--border-brand)'
  },
  quiet: {
    bg: 'var(--n-50)',
    bgHover: 'var(--n-100)',
    fg: 'var(--text-body)',
    shadow: 'none',
    border: 'var(--border-subtle)'
  },
  ghost: {
    bg: 'transparent',
    bgHover: 'var(--n-50)',
    fg: 'var(--text-brand)',
    shadow: 'none',
    border: 'transparent'
  }
};
const moiraiButtonSize = {
  sm: {
    h: 'var(--control-h-sm)',
    px: '16px',
    font: 'var(--weight-bold) 14px/1 var(--font-text)',
    icon: 16,
    gap: '6px'
  },
  md: {
    h: 'var(--control-h-md)',
    px: '22px',
    font: 'var(--weight-bold) 16px/1 var(--font-text)',
    icon: 18,
    gap: '8px'
  },
  lg: {
    h: 'var(--control-h-lg)',
    px: '28px',
    font: 'var(--weight-bold) 18px/1 var(--font-text)',
    icon: 20,
    gap: '10px'
  }
};
function Button({
  variant = 'primary',
  size = 'md',
  iconLeft,
  iconRight,
  fullWidth = false,
  disabled = false,
  loading = false,
  children,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const t = moiraiButtonTone[variant] || moiraiButtonTone.primary;
  const s = moiraiButtonSize[size] || moiraiButtonSize.md;
  const off = disabled || loading;
  const dim = disabled; // loading keeps its tone, just dimmed
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: off,
    onClick: off ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onPointerDown: () => setPress(true),
    onPointerUp: () => setPress(false),
    style: {
      display: fullWidth ? 'flex' : 'inline-flex',
      width: fullWidth ? '100%' : 'auto',
      alignItems: 'center',
      justifyContent: 'center',
      gap: s.gap,
      minHeight: s.h,
      padding: `0 ${s.px}`,
      font: s.font,
      letterSpacing: '0.01em',
      whiteSpace: 'nowrap',
      color: off ? 'var(--text-faint)' : t.fg,
      background: off ? 'var(--n-50)' : hover && !press ? t.bgHover : t.bg,
      border: `1.5px solid ${off ? 'var(--border-subtle)' : t.border}`,
      borderRadius: 'var(--radius-pill)',
      boxShadow: off ? 'none' : press ? 'var(--shadow-press)' : hover ? t.shadow : t.shadow === 'none' ? 'none' : 'var(--shadow-1)',
      transform: press && !off ? 'scale(var(--press-scale))' : 'scale(1)',
      transition: 'var(--transition-control)',
      cursor: off ? 'not-allowed' : 'pointer',
      opacity: loading ? 0.68 : 1,
      WebkitTapHighlightColor: 'transparent',
      ...style
    }
  }, rest), iconLeft ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: s.icon,
    strokeWidth: 2.25
  }) : null, /*#__PURE__*/React.createElement("span", null, loading ? 'Un momento…' : children), iconRight ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: s.icon,
    strokeWidth: 2.25
  }) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const moiraiIconButtonTone = {
  plain: {
    bg: 'transparent',
    bgHover: 'var(--n-100)',
    fg: 'var(--text-body)'
  },
  soft: {
    bg: 'var(--n-50)',
    bgHover: 'var(--n-100)',
    fg: 'var(--text-body)'
  },
  brand: {
    bg: 'var(--sky-50)',
    bgHover: 'var(--sky-100)',
    fg: 'var(--sky-600)'
  },
  solid: {
    bg: 'var(--sky-500)',
    bgHover: 'var(--sky-600)',
    fg: 'var(--text-on-brand)'
  }
};
function IconButton({
  icon = 'more-horizontal',
  label = 'Más opciones',
  variant = 'plain',
  size = 'md',
  disabled = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const t = moiraiIconButtonTone[variant] || moiraiIconButtonTone.plain;
  const box = size === 'sm' ? 40 : size === 'lg' ? 56 : 48;
  const glyph = size === 'sm' ? 18 : size === 'lg' ? 26 : 22;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    disabled: disabled,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onPointerDown: () => setPress(true),
    onPointerUp: () => setPress(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: box,
      height: box,
      borderRadius: 'var(--radius-pill)',
      background: disabled ? 'transparent' : hover ? t.bgHover : t.bg,
      color: disabled ? 'var(--text-faint)' : t.fg,
      border: 'none',
      boxShadow: variant === 'solid' && !disabled ? 'var(--shadow-brand)' : 'none',
      transform: press && !disabled ? 'scale(var(--press-scale))' : 'scale(1)',
      transition: 'var(--transition-control)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      padding: 0,
      WebkitTapHighlightColor: 'transparent',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: glyph,
    strokeWidth: 2.25
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tag({
  selected = false,
  icon,
  onSelect,
  onRemove,
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const interactive = typeof onSelect === 'function';
  return /*#__PURE__*/React.createElement("span", _extends({
    onClick: onSelect,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '7px',
      minHeight: '40px',
      padding: '0 16px',
      background: selected ? 'var(--sky-100)' : hover && interactive ? 'var(--n-50)' : 'var(--surface-card)',
      color: selected ? 'var(--sky-700)' : 'var(--text-body)',
      border: `1.5px solid ${selected ? 'var(--sky-300)' : 'var(--border-default)'}`,
      borderRadius: 'var(--radius-chip)',
      font: 'var(--weight-semibold) 14px/1 var(--font-text)',
      whiteSpace: 'nowrap',
      cursor: interactive ? 'pointer' : 'default',
      transition: 'var(--transition-control)',
      WebkitTapHighlightColor: 'transparent',
      ...style
    }
  }, rest), icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16,
    strokeWidth: 2.25
  }) : null, children, onRemove ? /*#__PURE__*/React.createElement("span", {
    onClick: e => {
      e.stopPropagation();
      onRemove(e);
    },
    style: {
      display: 'inline-flex',
      marginRight: '-4px',
      opacity: 0.6
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 14,
    strokeWidth: 2.5
  })) : null);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/BottomSheet.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function BottomSheet({
  open = true,
  title,
  description,
  onClose,
  footer,
  children,
  height = 'auto',
  style,
  ...rest
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'flex-end',
      zIndex: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--surface-overlay)',
      animation: 'none'
    }
  }), /*#__PURE__*/React.createElement("section", _extends({
    style: {
      position: 'relative',
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-sheet) var(--radius-sheet) 0 0',
      boxShadow: 'var(--shadow-sheet)',
      padding: '10px var(--gutter-screen) 24px',
      height,
      maxHeight: '88%',
      overflowY: 'auto',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 44,
      height: 5,
      borderRadius: 'var(--radius-pill)',
      background: 'var(--n-200)',
      margin: '0 auto 14px'
    }
  }), onClose ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    onClick: onClose,
    style: {
      position: 'absolute',
      top: 12,
      right: 12
    }
  }) : null, title ? /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--weight-bold) 24px/1.25 var(--font-display)',
      color: 'var(--text-strong)',
      margin: '0 40px 6px 0',
      letterSpacing: 'var(--track-title)'
    }
  }, title) : null, description ? /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--weight-regular) 15px/1.55 var(--font-text)',
      color: 'var(--text-muted)',
      margin: '0 0 18px'
    }
  }, description) : null, children, footer ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '10px',
      marginTop: 22
    }
  }, footer) : null));
}
Object.assign(__ds_scope, { BottomSheet });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/BottomSheet.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Dialog({
  open = true,
  title,
  description,
  icon,
  onClose,
  footer,
  children,
  style,
  ...rest
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 24,
      zIndex: 50
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--surface-overlay)'
    }
  }), /*#__PURE__*/React.createElement("section", _extends({
    role: "dialog",
    style: {
      position: 'relative',
      width: '100%',
      maxWidth: 340,
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-card-lg)',
      boxShadow: 'var(--shadow-3)',
      padding: 'var(--space-7)',
      textAlign: 'center',
      ...style
    }
  }, rest), icon ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 56,
      height: 56,
      margin: '0 auto 14px',
      borderRadius: 'var(--radius-pill)',
      background: 'var(--surface-brand-soft)',
      color: 'var(--sky-500)',
      fontSize: 26
    }
  }, icon) : null, title ? /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--weight-bold) 22px/1.25 var(--font-display)',
      color: 'var(--text-strong)',
      margin: '0 0 8px'
    }
  }, title) : null, description ? /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--weight-regular) 15px/1.55 var(--font-text)',
      color: 'var(--text-muted)',
      margin: '0 0 20px'
    }
  }, description) : null, children, footer ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '10px',
      marginTop: 18
    }
  }, footer) : null));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Notice.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const moiraiNoticeTone = {
  info: {
    bg: 'var(--sky-50)',
    border: 'var(--sky-100)',
    fg: 'var(--sky-700)',
    icon: 'info'
  },
  good: {
    bg: 'var(--mint-50)',
    border: 'var(--mint-100)',
    fg: 'var(--mint-700)',
    icon: 'sparkles'
  },
  watch: {
    bg: 'var(--amber-50)',
    border: 'var(--amber-100)',
    fg: 'var(--amber-700)',
    icon: 'eye'
  },
  high: {
    bg: 'var(--clay-50)',
    border: 'var(--clay-100)',
    fg: 'var(--clay-700)',
    icon: 'heart-handshake'
  }
};
function Notice({
  tone = 'info',
  title,
  children,
  icon,
  action,
  style,
  ...rest
}) {
  const t = moiraiNoticeTone[tone] || moiraiNoticeTone.info;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      gap: '12px',
      padding: '14px 16px',
      background: t.bg,
      border: `1px solid ${t.border}`,
      borderRadius: 'var(--radius-lg)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      color: t.fg,
      marginTop: 1
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon || t.icon,
    size: 20,
    strokeWidth: 2.25
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, title ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--weight-bold) 15px/1.35 var(--font-text)',
      color: t.fg,
      marginBottom: 2
    }
  }, title) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--weight-regular) 14px/1.5 var(--font-text)',
      color: 'var(--text-body)'
    }
  }, children), action ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12
    }
  }, action) : null));
}
Object.assign(__ds_scope, { Notice });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Notice.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const moiraiToastTone = {
  good: {
    bg: 'var(--mint-600)',
    icon: 'check'
  },
  brand: {
    bg: 'var(--sky-600)',
    icon: 'info'
  },
  neutral: {
    bg: 'var(--n-800)',
    icon: 'info'
  }
};
function Toast({
  message,
  tone = 'good',
  icon,
  actionLabel,
  onAction,
  style,
  ...rest
}) {
  const t = moiraiToastTone[tone] || moiraiToastTone.good;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '12px',
      padding: '12px 16px',
      background: t.bg,
      color: 'var(--text-inverse)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-3)',
      font: 'var(--weight-semibold) 15px/1.35 var(--font-text)',
      maxWidth: 380,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon || t.icon,
    size: 19,
    strokeWidth: 2.5
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, message), actionLabel ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onAction,
    style: {
      border: 'none',
      background: 'transparent',
      color: 'var(--text-inverse)',
      font: 'var(--weight-bold) 14px/1 var(--font-text)',
      textDecoration: 'underline',
      textUnderlineOffset: '3px',
      cursor: 'pointer',
      padding: 0
    }
  }, actionLabel) : null);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tooltip({
  label,
  placement = 'top',
  children,
  style,
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const pos = placement === 'bottom' ? {
    top: 'calc(100% + 8px)',
    left: '50%',
    transform: 'translateX(-50%)'
  } : {
    bottom: 'calc(100% + 8px)',
    left: '50%',
    transform: 'translateX(-50%)'
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    onMouseEnter: () => setOpen(true),
    onMouseLeave: () => setOpen(false),
    onPointerDown: () => setOpen(v => !v),
    style: {
      position: 'relative',
      display: 'inline-flex',
      ...style
    }
  }, rest), children, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      ...pos,
      zIndex: 30,
      padding: '8px 12px',
      background: 'var(--n-800)',
      color: 'var(--text-inverse)',
      borderRadius: 'var(--radius-sm)',
      boxShadow: 'var(--shadow-2)',
      font: 'var(--weight-medium) 13px/1.4 var(--font-text)',
      whiteSpace: 'nowrap',
      pointerEvents: 'none',
      opacity: open ? 1 : 0,
      transform: `${pos.transform} translateY(${open ? '0' : placement === 'bottom' ? '-4px' : '4px'})`,
      transition: 'opacity var(--dur-fast) var(--ease-out), transform var(--dur-fast) var(--ease-out)'
    }
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  checked = false,
  onChange,
  label,
  description,
  disabled = false,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: description ? 'flex-start' : 'center',
      gap: '12px',
      minHeight: 'var(--tap-min)',
      padding: '4px 0',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: checked,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 26,
      height: 26,
      flex: '0 0 auto',
      marginTop: description ? '2px' : 0,
      borderRadius: '9px',
      background: checked ? 'var(--sky-500)' : hover ? 'var(--n-50)' : 'var(--surface-card)',
      border: `1.5px solid ${checked ? 'var(--sky-500)' : 'var(--border-strong)'}`,
      color: 'var(--text-on-brand)',
      boxShadow: checked ? 'var(--shadow-1)' : 'none',
      transition: 'var(--transition-control)'
    }
  }, checked ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 17,
    strokeWidth: 3
  }) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '2px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-semibold) 16px/1.35 var(--font-text)',
      color: 'var(--text-strong)'
    }
  }, label), description ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-regular) 13px/1.45 var(--font-text)',
      color: 'var(--text-muted)'
    }
  }, description) : null));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  value,
  onChange,
  placeholder,
  hint,
  error,
  icon,
  suffix,
  type = 'text',
  size = 'md',
  disabled = false,
  id,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const inputId = id || React.useId();
  const h = size === 'lg' ? 'var(--control-h-lg)' : size === 'sm' ? 'var(--control-h-sm)' : 'var(--control-h-md)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      width: '100%',
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      font: 'var(--text-label-role)',
      color: 'var(--text-muted)',
      letterSpacing: 'var(--track-label)'
    }
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      minHeight: h,
      padding: '0 16px',
      background: disabled ? 'var(--n-50)' : 'var(--surface-card)',
      border: `1.5px solid ${error ? 'var(--clay-300)' : focus ? 'var(--sky-400)' : 'var(--border-default)'}`,
      borderRadius: 'var(--radius-control)',
      boxShadow: focus ? 'var(--ring-focus)' : 'none',
      transition: 'var(--transition-control)'
    }
  }, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 18,
    color: "var(--text-faint)"
  }) : null, /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    type: type,
    value: value,
    placeholder: placeholder,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      font: type === 'number' ? 'var(--weight-bold) 18px/1.2 var(--font-numeric)' : 'var(--weight-medium) 16px/1.4 var(--font-text)',
      color: 'var(--text-strong)',
      padding: '10px 0'
    }
  }, rest)), suffix ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-semibold) 14px/1 var(--font-text)',
      color: 'var(--text-muted)'
    }
  }, suffix) : null), error || hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-medium) 13px/1.4 var(--font-text)',
      color: error ? 'var(--text-high)' : 'var(--text-muted)'
    }
  }, error || hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Radio({
  checked = false,
  onChange,
  label,
  description,
  name,
  value,
  disabled = false,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: description ? 'flex-start' : 'center',
      gap: '12px',
      minHeight: 'var(--tap-min)',
      padding: '10px 14px',
      background: checked ? 'var(--sky-50)' : hover ? 'var(--n-25)' : 'transparent',
      border: `1.5px solid ${checked ? 'var(--sky-300)' : 'var(--border-subtle)'}`,
      borderRadius: 'var(--radius-md)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      transition: 'var(--transition-control)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("input", {
    type: "radio",
    name: name,
    value: value,
    checked: checked,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 24,
      height: 24,
      flex: '0 0 auto',
      marginTop: description ? '2px' : 0,
      borderRadius: 'var(--radius-pill)',
      background: 'var(--surface-card)',
      border: `2px solid ${checked ? 'var(--sky-500)' : 'var(--border-strong)'}`,
      transition: 'var(--transition-control)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 12,
      height: 12,
      borderRadius: 'var(--radius-pill)',
      background: checked ? 'var(--sky-500)' : 'transparent',
      transition: 'var(--transition-control)'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '2px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-semibold) 16px/1.35 var(--font-text)',
      color: 'var(--text-strong)'
    }
  }, label), description ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-regular) 13px/1.45 var(--font-text)',
      color: 'var(--text-muted)'
    }
  }, description) : null));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/RangeSlider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function RangeSlider({
  label,
  value = 0,
  min = 0,
  max = 100,
  step = 1,
  onChange,
  valueLabel,
  minLabel,
  maxLabel,
  tone = 'brand',
  disabled = false,
  style,
  ...rest
}) {
  const pct = Math.max(0, Math.min(100, (value - min) / (max - min) * 100));
  const fill = tone === 'good' ? 'var(--mint-400)' : tone === 'watch' ? 'var(--amber-300)' : 'var(--sky-400)';
  const knob = tone === 'good' ? 'var(--mint-500)' : tone === 'watch' ? 'var(--amber-400)' : 'var(--sky-500)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '10px',
      width: '100%',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, label || valueLabel ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-semibold) 15px/1.3 var(--font-text)',
      color: 'var(--text-body)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-bold) 24px/1 var(--font-numeric)',
      color: 'var(--text-strong)',
      letterSpacing: 'var(--track-num)'
    }
  }, valueLabel ?? value)) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 28,
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      height: 10,
      borderRadius: 'var(--radius-pill)',
      background: 'var(--n-100)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      width: pct + '%',
      height: 10,
      borderRadius: 'var(--radius-pill)',
      background: fill,
      transition: 'width var(--dur-fast) var(--ease-out)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: `calc(${pct}% - 14px)`,
      width: 28,
      height: 28,
      borderRadius: 'var(--radius-pill)',
      background: 'var(--n-0)',
      border: `3px solid ${knob}`,
      boxShadow: 'var(--shadow-2)',
      pointerEvents: 'none',
      transition: 'left var(--dur-fast) var(--ease-out)'
    }
  }), /*#__PURE__*/React.createElement("input", _extends({
    type: "range",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: 'relative',
      width: '100%',
      height: 28,
      margin: 0,
      opacity: 0,
      cursor: disabled ? 'not-allowed' : 'pointer'
    }
  }, rest))), minLabel || maxLabel ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      font: 'var(--weight-medium) 12px/1 var(--font-text)',
      color: 'var(--text-faint)'
    }
  }, /*#__PURE__*/React.createElement("span", null, minLabel), /*#__PURE__*/React.createElement("span", null, maxLabel)) : null);
}
Object.assign(__ds_scope, { RangeSlider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/RangeSlider.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  value,
  onChange,
  options = [],
  hint,
  disabled = false,
  id,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const selectId = id || React.useId();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      width: '100%',
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: selectId,
    style: {
      font: 'var(--text-label-role)',
      color: 'var(--text-muted)',
      letterSpacing: 'var(--track-label)'
    }
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      minHeight: 'var(--control-h-md)',
      padding: '0 14px 0 16px',
      background: disabled ? 'var(--n-50)' : 'var(--surface-card)',
      border: `1.5px solid ${focus ? 'var(--sky-400)' : 'var(--border-default)'}`,
      borderRadius: 'var(--radius-control)',
      boxShadow: focus ? 'var(--ring-focus)' : 'none',
      transition: 'var(--transition-control)'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: selectId,
    value: value,
    onChange: onChange,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      appearance: 'none',
      WebkitAppearance: 'none',
      border: 'none',
      outline: 'none',
      background: 'transparent',
      font: 'var(--weight-semibold) 16px/1 var(--font-text)',
      color: 'var(--text-strong)',
      padding: '12px 0',
      cursor: disabled ? 'not-allowed' : 'pointer'
    }
  }, rest), options.map(o => {
    const opt = typeof o === 'string' ? {
      value: o,
      label: o
    } : o;
    return /*#__PURE__*/React.createElement("option", {
      key: opt.value,
      value: opt.value
    }, opt.label);
  })), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 18,
    color: "var(--text-muted)"
  })), hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-medium) 13px/1.4 var(--font-text)',
      color: 'var(--text-muted)'
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Switch({
  checked = false,
  onChange,
  label,
  description,
  disabled = false,
  style,
  ...rest
}) {
  const track = checked ? 'var(--mint-400)' : 'var(--n-200)';
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '16px',
      justifyContent: 'space-between',
      minHeight: 'var(--tap-min)',
      width: '100%',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '2px'
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-semibold) 16px/1.35 var(--font-text)',
      color: 'var(--text-strong)'
    }
  }, label) : null, description ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-regular) 13px/1.45 var(--font-text)',
      color: 'var(--text-muted)'
    }
  }, description) : null), /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    role: "switch",
    checked: checked,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      flex: '0 0 auto',
      width: 54,
      height: 32,
      background: track,
      borderRadius: 'var(--radius-pill)',
      boxShadow: checked ? 'inset 0 0 0 1px rgba(27,134,89,.2)' : 'inset 0 0 0 1px rgba(35,45,53,.06)',
      transition: 'background-color var(--dur-base) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 3,
      left: checked ? 25 : 3,
      width: 26,
      height: 26,
      background: 'var(--n-0)',
      borderRadius: 'var(--radius-pill)',
      boxShadow: '0 2px 6px rgba(35,45,53,.18)',
      transition: 'left var(--dur-base) var(--ease-bounce)'
    }
  })));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/health/BigStat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const moiraiStatState = {
  good: {
    ink: 'var(--sky-600)',
    soft: 'var(--sky-100)',
    word: 'Va muy bien'
  },
  steady: {
    ink: 'var(--state-steady-ink)',
    soft: 'var(--sky-100)',
    word: 'Estable'
  },
  watch: {
    ink: 'var(--state-watch-ink)',
    soft: 'var(--amber-100)',
    word: 'Vale la pena revisarlo'
  },
  high: {
    ink: 'var(--state-high-ink)',
    soft: 'var(--clay-100)',
    word: 'Vale la pena consultarlo'
  },
  none: {
    ink: 'var(--text-strong)',
    soft: 'var(--n-100)',
    word: ''
  }
};
const moiraiStatSize = {
  sm: {
    font: 'var(--text-stat-md)',
    unit: 16
  },
  md: {
    font: 'var(--text-stat-lg)',
    unit: 20
  },
  lg: {
    font: 'var(--text-stat-xl)',
    unit: 24
  },
  hero: {
    font: 'var(--text-hero)',
    unit: 28
  }
};

/** Counts from 0 to the value on mount / value change. */
function useCountUp(target, animate) {
  const numeric = typeof target === 'number' && isFinite(target);
  const [shown, setShown] = React.useState(numeric && animate ? 0 : target);
  React.useEffect(() => {
    const reduced = typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!numeric || !animate || reduced) {
      setShown(target);
      return;
    }
    const dur = 900,
      start = performance.now(),
      from = 0;
    let raf;
    const tick = now => {
      const p = Math.min(1, (now - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      const decimals = String(target).includes('.') ? 1 : 0;
      setShown(+(from + (target - from) * eased).toFixed(decimals));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    // Safety net: if rAF is throttled (background tab, offscreen frame) commit the real value anyway.
    const settle = setTimeout(() => setShown(target), dur + 120);
    return () => {
      cancelAnimationFrame(raf);
      clearTimeout(settle);
    };
  }, [target, numeric, animate]);
  return shown;
}
function BigStat({
  label,
  value,
  unit,
  state = 'none',
  size = 'md',
  icon,
  caption,
  delta,
  deltaDirection,
  animate = true,
  align = 'left',
  style,
  ...rest
}) {
  const s = moiraiStatState[state] || moiraiStatState.none;
  const z = moiraiStatSize[size] || moiraiStatSize.md;
  const shown = useCountUp(value, animate);
  const deltaGood = deltaDirection === 'good';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      alignItems: align === 'center' ? 'center' : 'flex-start',
      textAlign: align,
      ...style
    }
  }, rest), label ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '7px',
      color: 'var(--text-muted)'
    }
  }, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16,
    strokeWidth: 2.25
  }) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-semibold) 14px/1.3 var(--font-text)',
      letterSpacing: 'var(--track-label)'
    }
  }, label)) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: '8px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: z.font,
      color: s.ink,
      letterSpacing: 'var(--track-num)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, typeof shown === 'number' ? shown.toLocaleString('es-CO') : shown), unit ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-semibold) ${z.unit}px/1 var(--font-text)`,
      color: 'var(--text-muted)'
    }
  }, unit) : null, delta ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '3px',
      marginLeft: 2,
      color: deltaGood ? 'var(--text-good)' : 'var(--text-watch)',
      font: 'var(--weight-bold) 15px/1 var(--font-text)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: deltaGood ? 'trending-down' : 'trending-up',
    size: 15,
    strokeWidth: 2.5
  }), delta) : null), caption || state !== 'none' && s.word ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-medium) 14px/1.45 var(--font-text)',
      color: caption ? 'var(--text-muted)' : s.ink
    }
  }, caption || s.word) : null);
}
Object.assign(__ds_scope, { BigStat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/health/BigStat.jsx", error: String((e && e.message) || e) }); }

// components/health/InsightCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function InsightCard({
  icon = 'sparkles',
  tone = 'good',
  eyebrow,
  title,
  body,
  effect,
  effectLabel,
  onClick,
  footer,
  style,
  ...rest
}) {
  const inks = {
    good: 'var(--mint-600)',
    steady: 'var(--sky-600)',
    watch: 'var(--amber-600)',
    high: 'var(--clay-600)'
  };
  const tints = {
    good: 'var(--mint-100)',
    steady: 'var(--sky-100)',
    watch: 'var(--amber-100)',
    high: 'var(--clay-100)'
  };
  const ink = inks[tone] || inks.good;
  return /*#__PURE__*/React.createElement(__ds_scope.Card, _extends({
    tone: "plain",
    onClick: onClick,
    style: style
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '14px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 46,
      height: 46,
      flex: '0 0 auto',
      borderRadius: 'var(--radius-md)',
      background: tints[tone] || tints.good,
      color: ink
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 23,
    strokeWidth: 2.25
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, eyebrow ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--weight-bold) 11px/1.2 var(--font-text)',
      letterSpacing: 'var(--track-overline)',
      textTransform: 'uppercase',
      color: 'var(--text-faint)',
      marginBottom: 5
    }
  }, eyebrow) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--weight-bold) 17px/1.35 var(--font-display)',
      color: 'var(--text-strong)',
      letterSpacing: 'var(--track-title)'
    }
  }, title), body ? /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--weight-regular) 14px/1.55 var(--font-text)',
      color: 'var(--text-muted)',
      margin: '6px 0 0'
    }
  }, body) : null, effect ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: '8px',
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-bold) 34px/1 var(--font-numeric)',
      color: ink,
      letterSpacing: 'var(--track-num)'
    }
  }, effect), effectLabel ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-semibold) 14px/1.3 var(--font-text)',
      color: 'var(--text-muted)'
    }
  }, effectLabel) : null) : null, footer ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14
    }
  }, footer) : null), onClick ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-right",
    size: 18,
    color: "var(--text-faint)"
  }) : null));
}
Object.assign(__ds_scope, { InsightCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/health/InsightCard.jsx", error: String((e && e.message) || e) }); }

// components/health/MascotStage.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Moira, the Moirai mascot: a soft, abstract three.js character — a rounded droplet/pebble
   blob (not a sphere) with a gentle organic wobble and a small orbiting spark.
   Still an explicit PLACEHOLDER: pass \`src\` to load the real .glb when it exists.
   Falls back to a soft CSS orb if WebGL or the CDN is unavailable. */

const moiraiMoodPose = {
  calm: {
    tilt: -0.05,
    bob: 1.0,
    eye: 1.0,
    squash: 1.00,
    color: 0x7FBFEA,
    spark: 0xB9DEF7
  },
  cheer: {
    tilt: 0.10,
    bob: 1.8,
    eye: 1.15,
    squash: 1.05,
    color: 0x62B0E6,
    spark: 0xDBEEFB
  },
  thinking: {
    tilt: -0.18,
    bob: 0.6,
    eye: 0.82,
    squash: 0.96,
    color: 0x9BCFF0,
    spark: 0x8AC7EF
  },
  concerned: {
    tilt: 0.04,
    bob: 0.4,
    eye: 0.92,
    squash: 0.94,
    color: 0xA8D4F2,
    spark: 0xFFCB63
  }
};
function MascotStage({
  mood = 'calm',
  size = 200,
  src,
  spin = false,
  style,
  ...rest
}) {
  const holder = React.useRef(null);
  const [failed, setFailed] = React.useState(false);
  const pose = moiraiMoodPose[mood] || moiraiMoodPose.calm;
  React.useEffect(() => {
    let stop = false,
      cleanup = () => {};
    (async () => {
      try {
        const THREE = await import('https://esm.sh/three@0.169.0');
        if (stop || !holder.current) return;
        const el = holder.current;
        const renderer = new THREE.WebGLRenderer({
          antialias: true,
          alpha: true
        });
        renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
        renderer.setSize(size, size);
        el.innerHTML = '';
        el.appendChild(renderer.domElement);
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 100);
        camera.position.set(0, 0.1, 5.6);
        scene.add(new THREE.HemisphereLight(0xffffff, 0xdbeefb, 1.1));
        const key = new THREE.DirectionalLight(0xffffff, 1.15);
        key.position.set(2.2, 3.2, 4);
        scene.add(key);
        const rim = new THREE.DirectionalLight(0xb9def7, 0.75);
        rim.position.set(-3, -1.4, 2.2);
        scene.add(rim);
        const group = new THREE.Group();
        scene.add(group);
        if (src) {
          const {
            GLTFLoader
          } = await import('https://esm.sh/three@0.169.0/examples/jsm/loaders/GLTFLoader.js');
          const gltf = await new GLTFLoader().loadAsync(src);
          gltf.scene.name = 'Moira';
          group.add(gltf.scene);
        } else {
          // --- abstract bean/pebble: a sphere pushed around by smooth low-frequency noise ---
          const geo = new THREE.IcosahedronGeometry(1.32, 6);
          const pos = geo.attributes.position;
          const v = new THREE.Vector3();
          for (let i = 0; i < pos.count; i++) {
            v.fromBufferAttribute(pos, i);
            const n = v.clone().normalize();
            const push = 1 + 0.115 * Math.sin(n.y * 2.0 + 1.15) + 0.075 * Math.sin(n.x * 1.75 + 0.55) + 0.055 * Math.cos(n.z * 1.9 - 0.4) + 0.035 * Math.sin(n.x * 3.1 + n.y * 2.4);
            pos.setXYZ(i, n.x * 1.32 * push, n.y * 1.32 * push, n.z * 1.32 * push);
          }
          geo.computeVertexNormals();
          const bodyMesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({
            color: pose.color,
            roughness: 0.46,
            metalness: 0.0
          }));
          bodyMesh.name = 'MoiraBody';
          bodyMesh.scale.set(1.14, 1.0 * pose.squash, 0.94);
          bodyMesh.rotation.set(0.05, 0.32, -0.06);
          group.add(bodyMesh);
          const faceZ = 1.34;
          const eyeMat = new THREE.MeshStandardMaterial({
            color: 0x2c3b47,
            roughness: 0.28
          });
          [-0.42, 0.42].forEach((x, i) => {
            const eye = new THREE.Mesh(new THREE.SphereGeometry(0.155, 32, 32), eyeMat);
            eye.name = 'MoiraEye' + i;
            eye.position.set(x + 0.07, 0.23, faceZ - Math.abs(x) * 0.1);
            eye.scale.set(1, pose.eye, 0.72);
            group.add(eye);
          });
          const cheekMat = new THREE.MeshStandardMaterial({
            color: 0xffffff,
            roughness: 0.9,
            transparent: true,
            opacity: 0.3
          });
          [-0.78, 0.78].forEach((x, i) => {
            const cheek = new THREE.Mesh(new THREE.SphereGeometry(0.22, 24, 24), cheekMat);
            cheek.name = 'MoiraCheek' + i;
            cheek.position.set(x + 0.07, -0.1, faceZ - 0.42);
            cheek.scale.set(1, 0.58, 0.26);
            group.add(cheek);
          });
          const smile = new THREE.Mesh(new THREE.TorusGeometry(0.29, 0.052, 16, 48, Math.PI * 0.9), new THREE.MeshStandardMaterial({
            color: 0x2c3b47,
            roughness: 0.32
          }));
          smile.name = 'MoiraSmile';
          smile.position.set(0.08, -0.19, faceZ - 0.1);
          smile.rotation.set(0.12, 0, Math.PI * 1.05);
          group.add(smile);

          // small orbiting spark — the abstract half of the character
          const spark = new THREE.Mesh(new THREE.IcosahedronGeometry(0.16, 1), new THREE.MeshStandardMaterial({
            color: pose.spark,
            roughness: 0.34
          }));
          spark.name = 'MoiraSpark';
          group.add(spark);
          group.userData.spark = spark;
        }
        const t0 = performance.now();
        let raf;
        const loop = () => {
          const t = (performance.now() - t0) / 1000;
          group.position.y = Math.sin(t * 1.45) * 0.06 * pose.bob;
          group.rotation.z = pose.tilt + Math.sin(t * 0.75) * 0.025;
          group.rotation.y = spin ? t * 0.5 : Math.sin(t * 0.45) * 0.14;
          const sp = group.userData.spark;
          if (sp) {
            sp.position.set(Math.cos(t * 0.9) * 1.72, 1.02 + Math.sin(t * 1.3) * 0.18, Math.sin(t * 0.9) * 1.25);
            sp.rotation.set(t * 0.8, t * 0.6, 0);
          }
          renderer.render(scene, camera);
          raf = requestAnimationFrame(loop);
        };
        loop();
        cleanup = () => {
          cancelAnimationFrame(raf);
          renderer.dispose();
          if (el) el.innerHTML = '';
        };
      } catch (e) {
        if (!stop) setFailed(true);
      }
    })();
    return () => {
      stop = true;
      cleanup();
    };
  }, [mood, size, src, spin]);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: 'relative',
      width: size,
      height: size,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: '6%',
      background: 'radial-gradient(circle at 50% 46%, rgba(82,169,226,.28), rgba(82,169,226,0) 68%)',
      borderRadius: '50%',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    ref: holder,
    style: {
      position: 'relative',
      width: size,
      height: size
    }
  }), failed ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      width: size * 0.62,
      height: size * 0.62,
      borderRadius: '58% 42% 46% 54% / 52% 48% 52% 48%',
      background: 'var(--gradient-brand)',
      boxShadow: 'var(--shadow-2)'
    }
  }) : null);
}
Object.assign(__ds_scope, { MascotStage });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/health/MascotStage.jsx", error: String((e && e.message) || e) }); }

// components/health/ProgressRing.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const moiraiRingTone = {
  good: 'var(--mint-400)',
  steady: 'var(--sky-400)',
  watch: 'var(--amber-300)',
  high: 'var(--clay-300)'
};
function ProgressRing({
  value = 0,
  max = 100,
  size = 140,
  thickness = 14,
  tone = 'steady',
  label,
  valueText,
  animate = true,
  children,
  style,
  ...rest
}) {
  const pct = Math.max(0, Math.min(1, value / max));
  const [shown, setShown] = React.useState(animate ? 0 : pct);
  React.useEffect(() => {
    if (!animate) {
      setShown(pct);
      return;
    }
    const t = setTimeout(() => setShown(pct), 60);
    return () => clearTimeout(t);
  }, [pct, animate]);
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  const stroke = moiraiRingTone[tone] || moiraiRingTone.steady;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: 'relative',
      width: size,
      height: size,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    style: {
      display: 'block',
      transform: 'rotate(-90deg)'
    }
  }, /*#__PURE__*/React.createElement("circle", {
    cx: size / 2,
    cy: size / 2,
    r: r,
    fill: "none",
    stroke: "var(--n-100)",
    strokeWidth: thickness
  }), /*#__PURE__*/React.createElement("circle", {
    cx: size / 2,
    cy: size / 2,
    r: r,
    fill: "none",
    stroke: stroke,
    strokeWidth: thickness,
    strokeLinecap: "round",
    strokeDasharray: c,
    strokeDashoffset: c * (1 - shown),
    style: {
      transition: 'stroke-dashoffset var(--dur-reveal) var(--ease-soft)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '2px'
    }
  }, children || /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-bold) ${Math.round(size * 0.26)}px/1 var(--font-numeric)`,
      color: 'var(--text-strong)',
      letterSpacing: 'var(--track-num)'
    }
  }, valueText ?? value), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-semibold) 12px/1.2 var(--font-text)',
      color: 'var(--text-muted)',
      letterSpacing: 'var(--track-label)'
    }
  }, label) : null)));
}
Object.assign(__ds_scope, { ProgressRing });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/health/ProgressRing.jsx", error: String((e && e.message) || e) }); }

// components/health/RiskMeter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const moiraiBands = [{
  id: 'good',
  color: 'var(--state-good)',
  label: 'Bajo'
}, {
  id: 'steady',
  color: 'var(--state-steady)',
  label: 'Habitual'
}, {
  id: 'watch',
  color: 'var(--state-watch)',
  label: 'Elevado'
}, {
  id: 'high',
  color: 'var(--state-high)',
  label: 'Alto'
}];
function RiskMeter({
  value = 0.5,
  label,
  valueText,
  comparison,
  animate = true,
  style,
  ...rest
}) {
  const pct = Math.max(0, Math.min(1, value)) * 100;
  const [shown, setShown] = React.useState(animate ? 0 : pct);
  React.useEffect(() => {
    if (!animate) {
      setShown(pct);
      return;
    }
    const t = setTimeout(() => setShown(pct), 80);
    return () => clearTimeout(t);
  }, [pct, animate]);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '10px',
      width: '100%',
      ...style
    }
  }, rest), label || valueText ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-semibold) 14px/1.3 var(--font-text)',
      color: 'var(--text-muted)',
      letterSpacing: 'var(--track-label)'
    }
  }, label), valueText ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-bold) 22px/1 var(--font-numeric)',
      color: 'var(--text-strong)'
    }
  }, valueText) : null) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      paddingTop: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 3,
      height: 14
    }
  }, moiraiBands.map(b => /*#__PURE__*/React.createElement("div", {
    key: b.id,
    style: {
      flex: 1,
      background: b.color,
      borderRadius: 'var(--radius-pill)'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      left: `calc(${shown}% - 9px)`,
      transition: 'left var(--dur-reveal) var(--ease-soft)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 18,
      height: 18,
      borderRadius: 'var(--radius-pill)',
      background: 'var(--n-0)',
      border: '3px solid var(--n-700)',
      boxShadow: 'var(--shadow-2)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 3,
      height: 14,
      margin: '0 auto',
      background: 'var(--n-700)',
      borderRadius: 2,
      opacity: 0.25
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      font: 'var(--weight-semibold) 11px/1 var(--font-text)',
      color: 'var(--text-faint)',
      letterSpacing: 'var(--track-label)'
    }
  }, moiraiBands.map(b => /*#__PURE__*/React.createElement("span", {
    key: b.id,
    style: {
      flex: 1,
      textAlign: 'center'
    }
  }, b.label))), comparison ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-medium) 13px/1.5 var(--font-text)',
      color: 'var(--text-muted)'
    }
  }, comparison) : null);
}
Object.assign(__ds_scope, { RiskMeter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/health/RiskMeter.jsx", error: String((e && e.message) || e) }); }

// components/health/TrendSpark.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function TrendSpark({
  points = [],
  tone = 'steady',
  height = 72,
  showArea = true,
  label,
  style,
  ...rest
}) {
  const stroke = tone === 'good' ? 'var(--mint-400)' : tone === 'watch' ? 'var(--amber-400)' : tone === 'high' ? 'var(--clay-400)' : 'var(--sky-400)';
  const w = 300,
    h = height;
  const vals = points.length ? points : [0, 0];
  const min = Math.min(...vals),
    max = Math.max(...vals);
  const span = max - min || 1;
  const step = vals.length > 1 ? w / (vals.length - 1) : w;
  const coords = vals.map((v, i) => [i * step, h - 8 - (v - min) / span * (h - 20)]);
  const line = coords.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
  const area = `${line} L${w},${h} L0,${h} Z`;
  const last = coords[coords.length - 1];
  const gid = React.useId().replace(/[^a-zA-Z0-9]/g, '');
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: '100%',
      ...style
    }
  }, rest), label ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--weight-semibold) 13px/1.3 var(--font-text)',
      color: 'var(--text-muted)',
      marginBottom: 8,
      letterSpacing: 'var(--track-label)'
    }
  }, label) : null, /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${w} ${h}`,
    preserveAspectRatio: "none",
    style: {
      display: 'block',
      width: '100%',
      height
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: gid,
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0%",
    stopColor: stroke,
    stopOpacity: "0.22"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: stroke,
    stopOpacity: "0"
  }))), showArea ? /*#__PURE__*/React.createElement("path", {
    d: area,
    fill: `url(#${gid})`
  }) : null, /*#__PURE__*/React.createElement("path", {
    d: line,
    fill: "none",
    stroke: stroke,
    strokeWidth: "3.5",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    vectorEffect: "non-scaling-stroke"
  }), last ? /*#__PURE__*/React.createElement("circle", {
    cx: last[0],
    cy: last[1],
    r: "4.5",
    fill: "var(--n-0)",
    stroke: stroke,
    strokeWidth: "3",
    vectorEffect: "non-scaling-stroke"
  }) : null));
}
Object.assign(__ds_scope, { TrendSpark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/health/TrendSpark.jsx", error: String((e && e.message) || e) }); }

// components/navigation/BottomNav.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function BottomNav({
  items = [],
  value,
  onChange,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    style: {
      display: 'flex',
      alignItems: 'stretch',
      height: 'var(--bottomnav-h)',
      padding: '0 8px',
      background: 'var(--surface-glass)',
      backdropFilter: 'var(--blur-glass)',
      WebkitBackdropFilter: 'var(--blur-glass)',
      borderTop: '1px solid var(--border-subtle)',
      ...style
    }
  }, rest), items.map(item => {
    const active = item.id === value;
    return /*#__PURE__*/React.createElement("button", {
      key: item.id,
      type: "button",
      onClick: () => onChange && onChange(item.id),
      style: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '4px',
        border: 'none',
        background: 'transparent',
        cursor: 'pointer',
        padding: '6px 0',
        color: active ? 'var(--sky-600)' : 'var(--text-faint)',
        WebkitTapHighlightColor: 'transparent'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        width: 52,
        height: 30,
        borderRadius: 'var(--radius-pill)',
        background: active ? 'var(--sky-100)' : 'transparent',
        transition: 'background-color var(--dur-base) var(--ease-out)'
      }
    }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: item.icon,
      size: 22,
      strokeWidth: active ? 2.5 : 2
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        font: `var(--weight-${active ? 'bold' : 'semibold'}) 11px/1 var(--font-text)`,
        letterSpacing: 'var(--track-label)'
      }
    }, item.label));
  }));
}
Object.assign(__ds_scope, { BottomNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/BottomNav.jsx", error: String((e && e.message) || e) }); }

// components/navigation/ListRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ListRow({
  icon,
  iconTone = 'brand',
  title,
  meta,
  value,
  onClick,
  trailingIcon,
  last = false,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const tones = {
    brand: {
      bg: 'var(--sky-50)',
      fg: 'var(--sky-600)'
    },
    good: {
      bg: 'var(--mint-50)',
      fg: 'var(--mint-600)'
    },
    watch: {
      bg: 'var(--amber-50)',
      fg: 'var(--amber-600)'
    },
    high: {
      bg: 'var(--clay-50)',
      fg: 'var(--clay-600)'
    },
    neutral: {
      bg: 'var(--n-50)',
      fg: 'var(--text-muted)'
    }
  };
  const t = tones[iconTone] || tones.brand;
  const tappable = typeof onClick === 'function';
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '14px',
      minHeight: 'var(--tap-comfort)',
      padding: '12px 4px',
      borderBottom: last ? 'none' : '1px solid var(--border-subtle)',
      background: tappable && hover ? 'var(--n-25)' : 'transparent',
      cursor: tappable ? 'pointer' : 'default',
      transition: 'background-color var(--dur-fast) var(--ease-out)',
      WebkitTapHighlightColor: 'transparent',
      ...style
    }
  }, rest), icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 42,
      height: 42,
      flex: '0 0 auto',
      borderRadius: 'var(--radius-md)',
      background: t.bg,
      color: t.fg
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 21,
    strokeWidth: 2.25
  })) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: '2px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-semibold) 16px/1.3 var(--font-text)',
      color: 'var(--text-strong)'
    }
  }, title), meta ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-regular) 13px/1.4 var(--font-text)',
      color: 'var(--text-muted)'
    }
  }, meta) : null), value ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-bold) 20px/1 var(--font-numeric)',
      color: 'var(--text-strong)',
      letterSpacing: 'var(--track-num)'
    }
  }, value) : null, tappable || trailingIcon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: trailingIcon || 'chevron-right',
    size: 18,
    color: "var(--text-faint)"
  }) : null);
}
Object.assign(__ds_scope, { ListRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/ListRow.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tabs({
  items = [],
  value,
  onChange,
  variant = 'segmented',
  style,
  ...rest
}) {
  const segmented = variant === 'segmented';
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    style: {
      display: 'flex',
      gap: segmented ? '4px' : '20px',
      alignItems: 'center',
      padding: segmented ? '4px' : '0',
      background: segmented ? 'var(--surface-sunken)' : 'transparent',
      borderRadius: segmented ? 'var(--radius-pill)' : 0,
      borderBottom: segmented ? 'none' : '1px solid var(--border-subtle)',
      ...style
    }
  }, rest), items.map(item => {
    const id = typeof item === 'string' ? item : item.id;
    const label = typeof item === 'string' ? item : item.label;
    const active = id === value;
    return /*#__PURE__*/React.createElement("button", {
      key: id,
      role: "tab",
      "aria-selected": active,
      type: "button",
      onClick: () => onChange && onChange(id),
      style: {
        flex: segmented ? 1 : '0 0 auto',
        minHeight: segmented ? 40 : 44,
        padding: segmented ? '0 14px' : '0 2px 12px',
        border: 'none',
        cursor: 'pointer',
        background: segmented ? active ? 'var(--surface-card)' : 'transparent' : 'transparent',
        boxShadow: segmented && active ? 'var(--shadow-1)' : 'none',
        borderRadius: segmented ? 'var(--radius-pill)' : 0,
        borderBottom: segmented ? 'none' : `2.5px solid ${active ? 'var(--sky-500)' : 'transparent'}`,
        color: active ? 'var(--text-strong)' : 'var(--text-muted)',
        font: `var(--weight-${active ? 'bold' : 'semibold'}) 14px/1 var(--font-text)`,
        transition: 'var(--transition-control)',
        WebkitTapHighlightColor: 'transparent'
      }
    }, label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/TopAppBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function TopAppBar({
  title,
  subtitle,
  backIcon,
  onBack,
  actionIcon,
  actionLabel,
  onAction,
  transparent = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("header", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      minHeight: 'var(--appbar-h)',
      padding: '8px var(--gutter-screen)',
      background: transparent ? 'transparent' : 'var(--surface-glass)',
      backdropFilter: transparent ? 'none' : 'var(--blur-glass)',
      WebkitBackdropFilter: transparent ? 'none' : 'var(--blur-glass)',
      borderBottom: transparent ? '1px solid transparent' : '1px solid var(--border-subtle)',
      ...style
    }
  }, rest), onBack ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: backIcon || 'chevron-left',
    label: "Atr\xE1s",
    onClick: onBack,
    style: {
      marginLeft: '-10px'
    }
  }) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, title ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--weight-bold) 20px/1.25 var(--font-display)',
      color: 'var(--text-strong)',
      letterSpacing: 'var(--track-title)'
    }
  }, title) : null, subtitle ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--weight-medium) 13px/1.3 var(--font-text)',
      color: 'var(--text-muted)'
    }
  }, subtitle) : null), actionIcon ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: actionIcon,
    label: actionLabel || 'Acción',
    onClick: onAction,
    style: {
      marginRight: '-10px'
    }
  }) : null);
}
Object.assign(__ds_scope, { TopAppBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/TopAppBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/android_app/App.jsx
try { (() => {
const {
  BottomNav,
  Toast
} = window.EvaraHealthDesignSystem_a5caa1;
const moiraiPhone = {
  frame: {
    position: 'relative',
    width: 400,
    height: 812,
    borderRadius: 44,
    background: 'var(--surface-page)',
    boxShadow: '0 32px 80px rgba(30,110,169,.22), 0 0 0 10px #1b2530, 0 0 0 12px #2b3a47',
    overflow: 'hidden',
    display: 'flex',
    flexDirection: 'column'
  },
  status: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '10px 22px 2px',
    font: 'var(--weight-bold) 13px/1 var(--font-text)',
    color: 'var(--text-strong)',
    flex: '0 0 auto',
    position: 'relative',
    zIndex: 5
  },
  body: {
    position: 'relative',
    flex: 1,
    minHeight: 0,
    display: 'flex',
    flexDirection: 'column'
  }
};
function Glyph({
  name,
  size = 16
}) {
  const {
    Icon
  } = window.EvaraHealthDesignSystem_a5caa1;
  return /*#__PURE__*/React.createElement(Icon, {
    name: name,
    size: size,
    strokeWidth: 2.25
  });
}
function StatusBar() {
  return /*#__PURE__*/React.createElement("div", {
    style: moiraiPhone.status
  }, /*#__PURE__*/React.createElement("span", null, "9:41"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 6,
      alignItems: 'center',
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement(Glyph, {
    name: "wifi",
    size: 15
  }), /*#__PURE__*/React.createElement(Glyph, {
    name: "signal",
    size: 15
  }), /*#__PURE__*/React.createElement(Glyph, {
    name: "battery-full",
    size: 17
  })));
}
function App() {
  const [stage, setStage] = React.useState('onboarding');
  const [tab, setTab] = React.useState('today');
  const [toast, setToast] = React.useState(null);
  const [scenario, setScenario] = React.useState({
    sleep: 6.5,
    steps: 6000,
    alcohol: 6,
    smoking: false
  });
  const [saved, setSaved] = React.useState(false);
  const notify = message => {
    setToast(message);
    setTimeout(() => setToast(null), 2600);
  };
  const screen = () => {
    if (stage === 'onboarding') return /*#__PURE__*/React.createElement(Onboarding, {
      onDone: () => setStage('app')
    });
    if (tab === 'today') return /*#__PURE__*/React.createElement(TodayScreen, {
      onOpenOutlook: () => setTab('outlook'),
      onSimulate: () => setTab('simulate')
    });
    if (tab === 'simulate') return /*#__PURE__*/React.createElement(SimulateScreen, {
      scenario: scenario,
      setScenario: setScenario,
      onSave: () => {
        setSaved(true);
        notify('Guardado en su plan');
        setTab('today');
      }
    });
    if (tab === 'outlook') return /*#__PURE__*/React.createElement(OutlookScreen, {
      onBack: () => setTab('today')
    });
    if (tab === 'habits') return /*#__PURE__*/React.createElement(HabitsScreen, {
      saved: saved,
      onSimulate: () => setTab('simulate')
    });
    return /*#__PURE__*/React.createElement(YouScreen, {
      onRestart: () => {
        setStage('onboarding');
        setTab('today');
      }
    });
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: moiraiPhone.frame
  }, /*#__PURE__*/React.createElement(StatusBar, null), /*#__PURE__*/React.createElement("div", {
    style: moiraiPhone.body
  }, screen(), toast ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 16,
      right: 16,
      bottom: stage === 'app' ? 88 : 20,
      display: 'flex',
      justifyContent: 'center',
      zIndex: 60
    }
  }, /*#__PURE__*/React.createElement(Toast, {
    tone: "good",
    message: toast
  })) : null), stage === 'app' ? /*#__PURE__*/React.createElement(BottomNav, {
    value: tab === 'outlook' ? 'today' : tab,
    onChange: setTab,
    items: [{
      id: 'today',
      label: 'Hoy',
      icon: 'sun'
    }, {
      id: 'simulate',
      label: 'Simular',
      icon: 'sliders-horizontal'
    }, {
      id: 'habits',
      label: 'Hábitos',
      icon: 'sprout'
    }, {
      id: 'you',
      label: 'Usted',
      icon: 'user-round'
    }]
  }) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 250,
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--weight-bold) 22px/1.2 var(--font-display)',
      color: 'var(--text-strong)',
      letterSpacing: 'var(--track-title)'
    }
  }, "Moirai"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      font: 'var(--weight-regular) 14px/1.6 var(--font-text)',
      color: 'var(--text-muted)'
    }
  }, "Click-through recreation of the Android app. The product UI is written in Colombian Spanish (usted, no slang); this panel is kit chrome."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      font: 'var(--weight-semibold) 13px/1.6 var(--font-text)',
      color: 'var(--text-faint)'
    }
  }, "Try: drag a scenario dial and watch the projection change, then tap \u201CGuardar en mi plan\u201D.")));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/android_app/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/android_app/HabitsScreen.jsx
try { (() => {
const {
  TopAppBar,
  Card,
  ListRow,
  Button,
  Badge,
  ProgressRing,
  Checkbox,
  InsightCard,
  Tabs
} = window.EvaraHealthDesignSystem_a5caa1;
function HabitsScreen({
  saved,
  onSimulate
}) {
  const [done, setDone] = React.useState({
    caminar: true,
    luz: false,
    agua: true
  });
  const [week, setWeek] = React.useState('Esta semana');
  const toggle = k => setDone({
    ...done,
    [k]: !done[k]
  });
  const count = Object.values(done).filter(Boolean).length;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(TopAppBar, {
    title: "H\xE1bitos",
    subtitle: "Peque\xF1os, repetibles, suyos"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: 'auto',
      padding: '4px var(--gutter-screen) 24px',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--stack-card)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    tone: "brand",
    elevation: 0,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(ProgressRing, {
    value: count,
    max: 3,
    size: 96,
    thickness: 12,
    tone: "steady",
    valueText: count + '/3',
    label: "hoy"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--weight-bold) 18px/1.3 var(--font-display)',
      color: 'var(--text-strong)'
    }
  }, "Van dos, falta uno"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '6px 0 0',
      font: 'var(--weight-regular) 14px/1.5 var(--font-text)',
      color: 'var(--text-muted)'
    }
  }, "Aqu\xED no hay rachas. Saltarse un d\xEDa no le cuesta nada."))), /*#__PURE__*/React.createElement(Tabs, {
    value: week,
    onChange: setWeek,
    items: ['Esta semana', 'La semana pasada']
  }), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    checked: done.caminar,
    onChange: () => toggle('caminar'),
    label: "Caminar despu\xE9s del almuerzo",
    description: "15 minutos, casi todos los d\xEDas"
  }), /*#__PURE__*/React.createElement(Checkbox, {
    checked: done.luz,
    onChange: () => toggle('luz'),
    label: "Apagar la luz antes de las 11:00 p. m.",
    description: "Su mayor palanca en este momento"
  }), /*#__PURE__*/React.createElement(Checkbox, {
    checked: done.agua,
    onChange: () => toggle('agua'),
    label: "Agua en cada comida"
  }))), saved ? /*#__PURE__*/React.createElement(InsightCard, {
    icon: "sparkles",
    tone: "good",
    eyebrow: "De su plan",
    title: "Dormir 7 horas cada noche",
    body: "Guardado desde su \xFAltimo escenario.",
    effect: "+2,4 a\xF1os",
    effectLabel: "de vida saludable proyectada",
    footer: /*#__PURE__*/React.createElement(Badge, {
      tone: "good",
      icon: "check"
    }, "En su plan")
  }) : /*#__PURE__*/React.createElement(Card, {
    tone: "sunken",
    elevation: 0,
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--weight-bold) 16px/1.35 var(--font-display)',
      color: 'var(--text-strong)'
    }
  }, "Todav\xEDa no hay nada guardado"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '6px 0 14px',
      font: 'var(--weight-regular) 14px/1.5 var(--font-text)',
      color: 'var(--text-muted)'
    }
  }, "Haga un escenario y guarde el que de verdad mantendr\xEDa."), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    iconRight: "chevron-right",
    onClick: onSimulate
  }, "Abrir Simular")), /*#__PURE__*/React.createElement(Card, {
    padding: "tight"
  }, /*#__PURE__*/React.createElement(ListRow, {
    icon: "calendar-days",
    iconTone: "neutral",
    title: "Hora del recordatorio",
    meta: "Cada ma\xF1ana",
    value: "8:00",
    onClick: () => {}
  }), /*#__PURE__*/React.createElement(ListRow, {
    icon: "sprout",
    iconTone: "good",
    title: "Agregar un h\xE1bito",
    meta: "Elija entre 12 sugerencias",
    onClick: () => {},
    last: true
  }))));
}
Object.assign(window, {
  HabitsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/android_app/HabitsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/android_app/Onboarding.jsx
try { (() => {
const {
  Button,
  Card,
  Tag,
  MascotStage,
  BigStat,
  Notice
} = window.EvaraHealthDesignSystem_a5caa1;
function Onboarding({
  onDone
}) {
  const [step, setStep] = React.useState(0);
  const [habits, setHabits] = React.useState(['camina']);
  const toggle = id => setHabits(h => h.includes(id) ? h.filter(x => x !== id) : [...h, id]);
  const wrap = {
    flex: 1,
    minHeight: 0,
    overflowY: 'auto',
    padding: '0 var(--gutter-screen) 24px',
    display: 'flex',
    flexDirection: 'column'
  };
  if (step === 0) return /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      alignItems: 'center',
      justifyContent: 'center',
      textAlign: 'center',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement(MascotStage, {
    mood: "calm",
    size: 200
  }), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--weight-bold) 30px/1.2 var(--font-display)',
      letterSpacing: 'var(--track-title)',
      color: 'var(--text-strong)',
      margin: '8px 0 0'
    }
  }, "Hola, soy Moira."), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--weight-regular) 16px/1.6 var(--font-text)',
      color: 'var(--text-muted)',
      margin: '10px 0 26px',
      maxWidth: 300
    }
  }, "Cu\xE9nteme un poco sobre sus d\xEDas y le muestro hacia d\xF3nde van, y qu\xE9 lograr\xEDa un cambio peque\xF1o."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    iconRight: "arrow-right",
    onClick: () => setStep(1)
  }, "Empecemos"), /*#__PURE__*/React.createElement("button", {
    onClick: onDone,
    style: {
      marginTop: 14,
      border: 'none',
      background: 'transparent',
      font: 'var(--weight-bold) 14px/1 var(--font-text)',
      color: 'var(--text-muted)',
      cursor: 'pointer'
    }
  }, "Ya hice esto antes"));
  if (step === 1) return /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 18
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-bold) 11px/1 var(--font-text)',
      letterSpacing: 'var(--track-overline)',
      textTransform: 'uppercase',
      color: 'var(--text-faint)'
    }
  }, "Paso 1 de 2"), /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--weight-bold) 26px/1.25 var(--font-display)',
      color: 'var(--text-strong)',
      margin: '8px 0 6px'
    }
  }, "\xBFCu\xE1les de estas se parecen a usted?"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--weight-regular) 15px/1.6 var(--font-text)',
      color: 'var(--text-muted)',
      margin: 0
    }
  }, "Elija todas las que apliquen. Puede cambiarlas cuando quiera.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 10
    }
  }, [['camina', 'Camino casi todos los días', 'footprints'], ['sueno', 'Duermo menos de 7 horas', 'moon'], ['fuma', 'Fumo', 'cigarette'], ['dejo', 'Dejé de fumar', 'cigarette-off'], ['alcohol', 'Tomo alcohol algunos días', 'wine'], ['verduras', 'Como verduras a diario', 'apple'], ['sentado', 'Paso el día sentado', 'armchair'], ['estres', 'Mis días son estresantes', 'wind']].map(([id, label, icon]) => /*#__PURE__*/React.createElement(Tag, {
    key: id,
    icon: icon,
    selected: habits.includes(id),
    onSelect: () => toggle(id)
  }, label))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      paddingTop: 18
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    iconRight: "arrow-right",
    onClick: () => setStep(2)
  }, "Siguiente")));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 18
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-bold) 11px/1 var(--font-text)',
      letterSpacing: 'var(--track-overline)',
      textTransform: 'uppercase',
      color: 'var(--text-faint)'
    }
  }, "Paso 2 de 2"), /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--weight-bold) 26px/1.25 var(--font-display)',
      color: 'var(--text-strong)',
      margin: '8px 0 6px'
    }
  }, "Este es su punto de partida")), /*#__PURE__*/React.createElement(Card, {
    tone: "plain",
    padding: "roomy",
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(MascotStage, {
    mood: "cheer",
    size: 132
  }), /*#__PURE__*/React.createElement(BigStat, {
    size: "lg",
    align: "center",
    label: "Edad del coraz\xF3n",
    value: 44,
    unit: "a\xF1os",
    state: "steady",
    caption: "Cerca de su edad real: 43 a\xF1os."
  })), /*#__PURE__*/React.createElement(Notice, {
    tone: "info",
    title: "Una estimaci\xF3n, no un diagn\xF3stico"
  }, "Comparamos lo que nos cont\xF3 con estudios de largo plazo de personas como usted. Moirai no puede examinarlo; un profesional de la salud s\xED."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      paddingTop: 14,
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    iconRight: "arrow-right",
    onClick: onDone
  }, "Ver mi d\xEDa"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "md",
    fullWidth: true,
    onClick: () => setStep(1)
  }, "Cambiar mis respuestas")));
}
Object.assign(window, {
  Onboarding
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/android_app/Onboarding.jsx", error: String((e && e.message) || e) }); }

// ui_kits/android_app/OutlookScreen.jsx
try { (() => {
const {
  TopAppBar,
  Card,
  BigStat,
  RiskMeter,
  TrendSpark,
  Tabs,
  ListRow,
  Notice,
  Button,
  BottomSheet
} = window.EvaraHealthDesignSystem_a5caa1;
function OutlookScreen({
  onBack
}) {
  const [section, setSection] = React.useState('Resumen');
  const [sheet, setSheet] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(TopAppBar, {
    title: "Su panorama",
    subtitle: "Actualizado esta ma\xF1ana",
    onBack: onBack,
    actionIcon: "share-2",
    actionLabel: "Compartir con mi m\xE9dico"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: 'auto',
      padding: '4px var(--gutter-screen) 24px',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--stack-card)'
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    variant: "underline",
    value: section,
    onChange: setSection,
    items: ['Resumen', 'Factores', 'Historial']
  }), /*#__PURE__*/React.createElement(Card, {
    padding: "roomy"
  }, /*#__PURE__*/React.createElement(BigStat, {
    size: "lg",
    label: "Edad del coraz\xF3n",
    value: 41,
    unit: "a\xF1os",
    state: "good",
    caption: "Su edad real es 43 a\xF1os.",
    icon: "heart-pulse"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--border-subtle)',
      margin: '20px 0'
    }
  }), /*#__PURE__*/React.createElement(RiskMeter, {
    value: 0.42,
    label: "Estimaci\xF3n cardiovascular a 10 a\xF1os",
    valueText: "9%",
    comparison: "La mayor\xEDa de las personas de su edad est\xE1 entre 8% y 15%."
  })), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(TrendSpark, {
    label: "Edad del coraz\xF3n en los \xFAltimos 2 a\xF1os",
    points: [46, 45.4, 45, 44.2, 43.5, 42.6, 41.8, 41],
    tone: "steady",
    height: 92
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '12px 0 0',
      font: 'var(--weight-regular) 14px/1.55 var(--font-text)',
      color: 'var(--text-muted)'
    }
  }, "La mayor parte vino de caminar m\xE1s. Mantenerlo es lo que sostiene el avance.")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--weight-bold) 18px/1.3 var(--font-display)',
      color: 'var(--text-strong)',
      margin: '8px 0 10px'
    }
  }, "Qu\xE9 lo est\xE1 moviendo"), /*#__PURE__*/React.createElement(Card, {
    padding: "tight"
  }, /*#__PURE__*/React.createElement(ListRow, {
    icon: "footprints",
    iconTone: "good",
    title: "Movimiento",
    meta: "Lo que m\xE1s ayuda",
    value: "+2,6"
  }), /*#__PURE__*/React.createElement(ListRow, {
    icon: "apple",
    iconTone: "good",
    title: "Alimentaci\xF3n",
    meta: "Ayuda",
    value: "+0,9"
  }), /*#__PURE__*/React.createElement(ListRow, {
    icon: "moon",
    iconTone: "watch",
    title: "Sue\xF1o",
    meta: "Lo que m\xE1s lo frena",
    value: "\u22121,4"
  }), /*#__PURE__*/React.createElement(ListRow, {
    icon: "droplets",
    iconTone: "watch",
    title: "Presi\xF3n arterial",
    meta: "Medida hace 3 d\xEDas",
    value: "\u22120,8",
    last: true
  }))), /*#__PURE__*/React.createElement(Notice, {
    tone: "high",
    title: "Vale la pena consultarlo",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "secondary",
      onClick: () => setSheet(true)
    }, "Qu\xE9 mencionar")
  }, "Su presi\xF3n arterial estuvo por encima de 135 en tres de sus \xFAltimas cuatro mediciones. Un m\xE9dico puede revisarla bien; Moirai no.")), /*#__PURE__*/React.createElement(BottomSheet, {
    open: sheet,
    onClose: () => setSheet(false),
    title: "Qu\xE9 mencionar en la consulta",
    description: "Tres puntos que vale la pena comentar en su pr\xF3xima cita. Puede compartir este resumen como un enlace de solo lectura.",
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "lg",
      fullWidth: true,
      iconLeft: "share-2"
    }, "Compartir resumen"), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "md",
      fullWidth: true,
      onClick: () => setSheet(false)
    }, "Cerrar"))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, ['Presión arterial por encima de 135 en 3 de 4 mediciones', 'Sueño promedio de 6,4 horas durante 8 semanas', 'Antecedentes familiares de enfermedad cardiaca'].map(t => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      padding: '12px 14px',
      background: 'var(--surface-sunken)',
      borderRadius: 'var(--radius-md)',
      font: 'var(--weight-semibold) 14px/1.45 var(--font-text)',
      color: 'var(--text-body)'
    }
  }, t)))));
}
Object.assign(window, {
  OutlookScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/android_app/OutlookScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/android_app/SimulateScreen.jsx
try { (() => {
const {
  TopAppBar,
  Card,
  BigStat,
  RangeSlider,
  Switch,
  Tabs,
  Button,
  Notice,
  MascotStage,
  Badge
} = window.EvaraHealthDesignSystem_a5caa1;
function SimulateScreen({
  scenario,
  setScenario,
  onSave
}) {
  const [range, setRange] = React.useState('10 años');
  const set = k => e => setScenario({
    ...scenario,
    [k]: +e.target.value
  });
  const gain = React.useMemo(() => {
    const sleep = (scenario.sleep - 6.5) * 1.6;
    const steps = (scenario.steps - 6000) / 1000 * 0.55;
    const alcohol = (6 - scenario.alcohol) * 0.18;
    const smoke = scenario.smoking ? -3.2 : 0;
    return Math.max(-6, Math.min(9, sleep + steps + alcohol + smoke));
  }, [scenario]);
  const positive = gain >= 0;
  const projected = 41 - gain * 0.55;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(TopAppBar, {
    title: "Simular",
    subtitle: "Mueva un control y vea qu\xE9 cambia"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: 'auto',
      padding: '4px var(--gutter-screen) 24px',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--stack-card)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    tone: positive ? 'brand' : 'watch',
    elevation: 0,
    padding: "roomy",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(MascotStage, {
    mood: positive ? 'cheer' : 'thinking',
    size: 104
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(BigStat, {
    size: "md",
    label: "A\xF1os de vida saludable",
    value: +Math.abs(gain).toFixed(1),
    unit: "a\xF1os",
    state: positive ? 'good' : 'watch',
    caption: positive ? 'que ganaría si esto fuera lo habitual' : 'que perdería frente a hoy',
    animate: false
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: positive ? 'good' : 'watch',
    icon: positive ? 'trending-down' : 'trending-up'
  }, "Edad del coraz\xF3n: ", projected.toFixed(0), " a\xF1os")))), /*#__PURE__*/React.createElement(Tabs, {
    value: range,
    onChange: setRange,
    items: ['1 año', '5 años', '10 años']
  }), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 22
    }
  }, /*#__PURE__*/React.createElement(RangeSlider, {
    label: "Sue\xF1o cada noche",
    value: scenario.sleep,
    min: 4,
    max: 10,
    step: 0.5,
    valueLabel: String(scenario.sleep).replace('.', ',') + ' h',
    minLabel: "4 h",
    maxLabel: "10 h",
    tone: "good",
    onChange: set('sleep')
  }), /*#__PURE__*/React.createElement(RangeSlider, {
    label: "Pasos al d\xEDa",
    value: scenario.steps,
    min: 1000,
    max: 14000,
    step: 500,
    valueLabel: scenario.steps.toLocaleString('es-CO'),
    minLabel: "1.000",
    maxLabel: "14.000",
    onChange: set('steps')
  }), /*#__PURE__*/React.createElement(RangeSlider, {
    label: "Tragos por semana",
    value: scenario.alcohol,
    min: 0,
    max: 21,
    step: 1,
    valueLabel: String(scenario.alcohol),
    minLabel: "Ninguno",
    maxLabel: "21",
    tone: "watch",
    onChange: set('alcohol')
  }), /*#__PURE__*/React.createElement(Switch, {
    checked: scenario.smoking,
    onChange: () => setScenario({
      ...scenario,
      smoking: !scenario.smoking
    }),
    label: "Fumo",
    description: "Apagarlo simula dejar de fumar hoy."
  }))), /*#__PURE__*/React.createElement(Notice, {
    tone: "info"
  }, "Los escenarios son promedios de grupos grandes. Su cuerpo puede responder m\xE1s r\xE1pido o m\xE1s lento."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    iconLeft: "check",
    onClick: onSave
  }, "Guardar en mi plan")));
}
Object.assign(window, {
  SimulateScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/android_app/SimulateScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/android_app/TodayScreen.jsx
try { (() => {
const {
  TopAppBar,
  Card,
  BigStat,
  InsightCard,
  Button,
  Badge,
  MascotStage,
  ProgressRing,
  TrendSpark,
  BottomSheet,
  IconButton,
  ListRow
} = window.EvaraHealthDesignSystem_a5caa1;
function TodayScreen({
  onOpenOutlook,
  onSimulate
}) {
  const [sheet, setSheet] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--gradient-page)'
    }
  }, /*#__PURE__*/React.createElement(TopAppBar, {
    transparent: true,
    title: "Hoy",
    subtitle: "Martes, 22 de agosto",
    actionIcon: "bell",
    actionLabel: "Recordatorios"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: 'auto',
      padding: '4px var(--gutter-screen) 24px',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--stack-card)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    tone: "plain",
    padding: "roomy",
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 2,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 12,
      right: 12
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "info",
    label: "C\xF3mo funciona",
    variant: "plain",
    size: "sm",
    onClick: () => setSheet(true)
  })), /*#__PURE__*/React.createElement(MascotStage, {
    mood: "cheer",
    size: 148
  }), /*#__PURE__*/React.createElement(BigStat, {
    size: "hero",
    align: "center",
    label: "Edad del coraz\xF3n",
    value: 41,
    unit: "a\xF1os",
    state: "good",
    caption: "Unos 3 a\xF1os menos que su edad real.",
    delta: "3 a\xF1os",
    deltaDirection: "good"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    iconRight: "chevron-right",
    onClick: onOpenOutlook,
    style: {
      marginTop: 14
    }
  }, "Ver el panorama")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "tight",
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(ProgressRing, {
    value: 8240,
    max: 10000,
    size: 104,
    tone: "steady",
    valueText: "82%",
    label: "de su d\xEDa"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-semibold) 13px/1.3 var(--font-text)',
      color: 'var(--text-muted)'
    }
  }, "8.240 pasos")), /*#__PURE__*/React.createElement(Card, {
    padding: "tight",
    style: {
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(BigStat, {
    size: "sm",
    label: "Sue\xF1o",
    value: 6.4,
    unit: "h",
    state: "watch",
    icon: "moon",
    animate: false
  }), /*#__PURE__*/React.createElement(TrendSpark, {
    points: [7.2, 6.8, 6.5, 6.9, 6.2, 6.4],
    tone: "watch",
    height: 48
  }), /*#__PURE__*/React.createElement(Badge, {
    tone: "watch",
    size: "sm"
  }, "Debajo de su meta de 7 h"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--weight-bold) 18px/1.3 var(--font-display)',
      color: 'var(--text-strong)',
      margin: '8px 0 10px'
    }
  }, "Qu\xE9 har\xEDa la diferencia"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement(InsightCard, {
    icon: "moon",
    tone: "steady",
    eyebrow: "\xBFY si\u2026?",
    title: "Durmiera 30 minutos m\xE1s",
    body: "Seg\xFAn sus \xFAltimas ocho semanas de sue\xF1o.",
    effect: "+2,4 a\xF1os",
    effectLabel: "de vida saludable proyectada",
    footer: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "secondary",
      onClick: onSimulate
    }, "Probar este escenario")
  }), /*#__PURE__*/React.createElement(InsightCard, {
    icon: "footprints",
    tone: "good",
    eyebrow: "\xBFY si\u2026?",
    title: "Caminara 2.000 pasos m\xE1s",
    body: "Son unos 18 minutos de su d\xEDa.",
    effect: "+1,1 a\xF1os",
    effectLabel: "de vida saludable proyectada",
    footer: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost",
      iconRight: "chevron-right",
      onClick: onSimulate
    }, "Probar este escenario")
  }))), /*#__PURE__*/React.createElement(Card, {
    padding: "tight"
  }, /*#__PURE__*/React.createElement(ListRow, {
    icon: "heart-pulse",
    iconTone: "brand",
    title: "Frecuencia cardiaca en reposo",
    meta: "Medida esta ma\xF1ana",
    value: "62",
    onClick: onOpenOutlook
  }), /*#__PURE__*/React.createElement(ListRow, {
    icon: "droplets",
    iconTone: "watch",
    title: "Presi\xF3n arterial",
    meta: "Hace 3 d\xEDas",
    value: "138/86",
    onClick: onOpenOutlook,
    last: true
  }))), /*#__PURE__*/React.createElement(BottomSheet, {
    open: sheet,
    onClose: () => setSheet(false),
    title: "De d\xF3nde sale este n\xFAmero",
    description: "Comparamos sus datos con estudios de largo plazo de personas como usted y le mostramos el punto medio de ese rango. Es una estimaci\xF3n, no un diagn\xF3stico, y cambia a medida que cambian sus h\xE1bitos.",
    footer: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "lg",
      fullWidth: true,
      onClick: () => setSheet(false)
    }, "Entendido")
  }));
}
Object.assign(window, {
  TodayScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/android_app/TodayScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/android_app/YouScreen.jsx
try { (() => {
const {
  TopAppBar,
  Card,
  ListRow,
  Switch,
  Button,
  Dialog,
  Input,
  Select,
  Badge,
  Icon
} = window.EvaraHealthDesignSystem_a5caa1;
function YouScreen({
  onRestart
}) {
  const [share, setShare] = React.useState(false);
  const [nudge, setNudge] = React.useState(true);
  const [confirm, setConfirm] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(TopAppBar, {
    title: "Usted",
    subtitle: "Sus datos y preferencias"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: 'auto',
      padding: '4px var(--gutter-screen) 24px',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--stack-card)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 56,
      height: 56,
      borderRadius: 'var(--radius-pill)',
      background: 'var(--gradient-brand)',
      font: 'var(--weight-bold) 22px/1 var(--font-display)',
      color: '#fff'
    }
  }, "MR"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--weight-bold) 18px/1.3 var(--font-display)',
      color: 'var(--text-strong)',
      whiteSpace: 'nowrap'
    }
  }, "Mariana Restrepo"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--weight-medium) 13px/1.4 var(--font-text)',
      color: 'var(--text-muted)',
      whiteSpace: 'nowrap'
    }
  }, "43 a\xF1os \xB7 Medell\xEDn")), /*#__PURE__*/React.createElement(Badge, {
    tone: "brand",
    size: "sm"
  }, "Estimaci\xF3n v4")), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Estatura",
    suffix: "cm",
    defaultValue: "168",
    icon: "ruler"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Peso",
    suffix: "kg",
    defaultValue: "71",
    icon: "scale"
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Unidades",
    options: ['Métrico (kg, cm)', 'Imperial (lb, ft)']
  }))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(Switch, {
    checked: nudge,
    onChange: () => setNudge(!nudge),
    label: "Chequeo de la ma\xF1ana",
    description: "Un recordatorio a las 8:00 a. m. Sin rachas ni culpa."
  }), /*#__PURE__*/React.createElement(Switch, {
    checked: share,
    onChange: () => setShare(!share),
    label: "Compartir con mi m\xE9dico",
    description: "Un enlace de solo lectura."
  }))), /*#__PURE__*/React.createElement(Card, {
    padding: "tight"
  }, /*#__PURE__*/React.createElement(ListRow, {
    icon: "shield-check",
    iconTone: "brand",
    title: "Sus datos",
    meta: "Guardados en este dispositivo",
    onClick: () => {}
  }), /*#__PURE__*/React.createElement(ListRow, {
    icon: "info",
    iconTone: "neutral",
    title: "C\xF3mo funcionan las estimaciones",
    onClick: () => {}
  }), /*#__PURE__*/React.createElement(ListRow, {
    icon: "heart-handshake",
    iconTone: "good",
    title: "Buscar apoyo",
    meta: "L\xEDneas de ayuda y servicios cerca de usted",
    onClick: () => {},
    last: true
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "quiet",
    size: "md",
    fullWidth: true,
    iconLeft: "rotate-ccw",
    onClick: () => setConfirm(true)
  }, "Reiniciar mi perfil")), /*#__PURE__*/React.createElement(Dialog, {
    open: confirm,
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "rotate-ccw",
      size: 26
    }),
    title: "\xBFReiniciar su perfil?",
    description: "Sus h\xE1bitos guardados se mantienen. Le preguntaremos de nuevo los dos datos iniciales.",
    onClose: () => setConfirm(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      fullWidth: true,
      onClick: () => {
        setConfirm(false);
        onRestart();
      }
    }, "Reiniciar"), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      fullWidth: true,
      onClick: () => setConfirm(false)
    }, "Mantener mi perfil"))
  }));
}
Object.assign(window, {
  YouScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/android_app/YouScreen.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.BottomSheet = __ds_scope.BottomSheet;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Notice = __ds_scope.Notice;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.RangeSlider = __ds_scope.RangeSlider;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.BigStat = __ds_scope.BigStat;

__ds_ns.InsightCard = __ds_scope.InsightCard;

__ds_ns.MascotStage = __ds_scope.MascotStage;

__ds_ns.ProgressRing = __ds_scope.ProgressRing;

__ds_ns.RiskMeter = __ds_scope.RiskMeter;

__ds_ns.TrendSpark = __ds_scope.TrendSpark;

__ds_ns.BottomNav = __ds_scope.BottomNav;

__ds_ns.ListRow = __ds_scope.ListRow;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.TopAppBar = __ds_scope.TopAppBar;

})();
