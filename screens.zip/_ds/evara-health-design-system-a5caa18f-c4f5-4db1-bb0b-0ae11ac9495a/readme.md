# Moirai — Design System

Moirai is a **health simulation app for Android**. A person tells it about their days — sleep, movement, drinking, smoking, a few measurements — and it projects where those days are heading, then lets them drag a dial to see what a small change would do. Its two hardest jobs are:

1. **Make numbers instantly understandable.** One big number per screen, in a rounded font, with a sentence underneath saying what it means.
2. **Deliver news, sometimes bad news, kindly.** Nothing in this system alarms. There is no red, no siren icon, no "high risk" verdict — every difficult number is paired with context and a next step, and a mascot named **Moira** is on screen to keep the tone human.

The product surface is one app (Android-first, but with its own visual language rather than stock Material). Everything here — tokens, components, the UI kit — exists to serve that app.

## Sources

**None were provided.** No codebase, Figma file, deck, screenshot or brand kit was attached; this system was authored from the written brief:

> Originally briefed as "Evara Health", renamed by the client to **Moirai** · health simulation app · friendly, big numbers, rounded font · Android but can have unique UI · light colours, light blue and light green, health-positive · big numbers anyone can understand · a three.js mascot to make it look friendly.

Consequences worth knowing before you build on it:
- **No logo exists.** The brand name is set in type wherever a mark would go. Nothing in `guidelines/brand-wordmark.html` is an approved mark.
- **Fonts are substitutions** (see Typography below) — flagged, not chosen from brand files.
- **Icons are Lucide from CDN** — a substitution, flagged.
- **The mascot geometry is a placeholder** built from three.js primitives, ready to be replaced by a real `.glb`.
- If any of the above exist somewhere, send them and this system should be re-pointed at the real assets.

---

## CONTENT FUNDAMENTALS

**Voice: a calm, well-informed friend who happens to know the research.** Not a doctor, not a coach, never a cheerleader.

- **Person.** Second person for the user ("your heart age", "you slept"), first person plural only for what the product did ("we compare your inputs with…"). Ev speaks in first person singular, and only in onboarding or empty states ("Hi, I'm Moira.").
- **Casing.** Sentence case everywhere — buttons, titles, nav labels, badges. Uppercase is reserved for 11px overline kickers (`WHAT IF`) and nothing else. No title case, ever.
- **Numbers.** Always figures, never words ("6.4 hrs", not "six point four"). Thousands get separators ("8,240"). One decimal maximum. Units are a separate, smaller, muted element beside the numeral.
- **Length.** Screen titles ≤ 4 words. Stat captions one sentence, ≤ 12 words. Body copy ≤ 2 sentences per block; if it needs more, it belongs in a bottom sheet.
- **Framing.** Gains, not penalties: "+2.4 yrs if you slept 30 minutes longer" — never "you're losing 2.4 years". Comparisons, not verdicts: "Most people your age sit between 8% and 15%". Concern routes to action: "Worth a conversation with your GP."
- **Uncertainty is stated, not buried.** "An estimate, not a diagnosis" appears wherever a projection is first shown.
- **Words we use:** looking good · steady · worth a look · worth a conversation · estimate · projected healthy years · what if · your outlook · small change.
- **Words we never use:** risk score · abnormal · critical · failure · deficient · you should have · congrats · crushed it · streak (Moirai deliberately has no streaks — "Missing a day costs you nothing").
- **Emoji: never.** Not in UI, not in copy, not in notifications. Warmth comes from the mascot, the rounded type and the colour, so emoji would read as flippant next to health news.
- **Error and empty states are help, not failure.** "That looks a little high — double-check?" · "Nothing saved yet. Run a scenario and save the one you'd actually keep up."

Full say/never-say card: `guidelines/voice.html`.

---

## VISUAL FOUNDATIONS

**Colour.** **Blue is the brand.** **Sky** (`--sky-*`) carries the identity: the mascot, every big number, primary actions, navigation, the page wash and the brand gradient (sky-300 → sky-500). **Mint** (`--mint-*`) is a *supporting accent only*, used small — badges, improvement deltas, an "on" switch, a good-tone icon tile — never for a hero figure or a full surface. Two support hues: **Amber** for attention and **Clay** — a muted coral — for the highest-concern state. *There is no alarm red in the system, at all.* Neutrals are cool-tinted (`--n-*`); there is no pure grey and no pure black (darkest ink is `--n-800 #232D35`). One ordered scale exists, the **status ramp**: good → steady → watch → high, each with a plain-language word attached. Backgrounds are white cards on a near-white page (`--n-25`), with at most one soft page wash.

**Typography.** Display + all numerals in **Quicksand** (geometric, fully rounded, unmistakable numerals); text in **Nunito** (rounded terminals, legible at 13px); **DM Mono** only for IDs and timestamps. Numerals run 96 / 72 / 56 / 40 / 28 px, bold, tabular, −0.015em. Body is 16/1.55. Weights used: 400, 500, 600, 700 (800 exists, unused). **Substitution flag:** no brand fonts were supplied — these three are the nearest Google Fonts matches for a friendly rounded voice and are loaded from CDN in `tokens/fonts.css`. Send real files and we'll self-host.

**Spacing & layout.** 4px base scale (`--space-1`…`--space-12`, 2→96). Phone gutter 20px, card padding 20px, 14px between stacked cards, 28px between sections. Design width 400–420px. Fixed elements: a 64px frosted top app bar and a 72px frosted bottom nav (3–4 items, always labelled); everything between them scrolls. Touch targets never below 48px; the screen-level CTA is 56px and full-width at the bottom of the scroll.

**Backgrounds.** No photography, no illustration, no patterns or textures. The only allowed backgrounds are flat surfaces and two soft gradients: a light-to-light page wash (`--gradient-page`, sky→white→mint at 170°) and `--gradient-brand` (sky-400→mint-400) for the rare filled surface — avatar rings, the "Moirai" lozenge. No purple, no dark-to-bright, no gradient text. Behind the mascot sits a single radial glow (sky at 30% → transparent).

**Cards.** White (`--surface-card`), 24px radius, 1px `--border-subtle` hairline, and a **sky-tinted** shadow (`--shadow-1`: `0 1px 2px rgba(35,45,53,.04), 0 2px 8px rgba(44,139,207,.06)`). Never neutral-black shadows. Tinted card variants (brand / good / watch / high) exist but are rationed to one per view. Nested groupings use `tone="sunken"` with elevation 0 rather than a second shadow. No coloured left-border cards.

**Corner radii.** Nothing sharp: 8px is the *smallest* radius in the system. 8 / 12 / 16 / 20 / **24 (cards)** / 28 / **32 (sheet tops)** / 36 / pill. All buttons, chips, badges and icon buttons are fully pill-rounded; checkboxes are 9px rounded squares.

**Shadows & rings.** Four elevations plus `--shadow-brand` (a sky glow under primary buttons), `--shadow-good` (mint), `--shadow-sheet` (upward lift under bottom sheets) and `--shadow-press`. Inner shadows are used only as a hairline (`--inner-hairline`) and on switch tracks. Focus is a 3px `--sky-200` ring, never a dark outline.

**Transparency & blur.** Exactly two uses: the app bar and bottom nav sit on `--surface-glass` (white at 72%) with a 14px backdrop blur, so content scrolls under them; and modal scrims use `--surface-overlay` (`rgba(21,28,34,.44)`). Content itself is never translucent. Where text meets a scrolling edge, use the bottom protection gradient (`--gradient-protect-bottom`) rather than a capsule.

**Motion.** Soft, never snappy. `--ease-soft` for reveals, `--ease-bounce` for the switch knob and the mascot's idle bob, `--ease-out` for state changes. Durations: 80 / 140 / 220 / 340 / 520, plus a 900ms **count-up** — big numbers always animate from zero rather than appearing, and never flash or pulse. Ring arcs sweep in over 520ms. The mascot breathes continuously (±0.055 units at ~1.5Hz); nothing else loops.

**Hover / press / disabled.** Hover **deepens the fill** by one step (sky-500 → sky-600) and raises the shadow — never an opacity change. Press **shrinks to 97%** (99% for cards) and drops the shadow to `--shadow-press`. Disabled is a neutral fill (`--n-50`) with faint text and a subtle border — never 50% alpha. Rows tint to `--n-25` on hover.

**Borders.** 1px hairlines (`--border-subtle`) between list rows and around cards; 1.5px for interactive borders (fields, chips, secondary buttons) so they hold their weight next to the rounded type; 2px on radio rings, 3px on slider knobs and ring strokes.

**Imagery vibe.** Cool, bright, low-contrast — the system's own washes rather than photographs. If photography is ever introduced: daylight, cool-neutral white balance, no grain, no dark editorial treatments, people mid-ordinary-day rather than mid-workout.

---

## ICONOGRAPHY

- **Set: [Lucide](https://lucide.dev) 0.469.0, loaded from CDN** — `https://unpkg.com/lucide@0.469.0/dist/umd/lucide.min.js`. **This is a flagged substitution:** no icon assets were supplied, and Lucide's 2px rounded-cap outline strokes are the closest match to Moirai's rounded geometry. Confirm or replace.
- **Always via the `Icon` component** (`components/core/Icon.jsx`), never inline SVG in a screen. It renders `<i data-lucide="…">` and normalises size/stroke.
- **Sizes:** 16 inside chips and captions · 18–20 inside buttons and fields · 22–24 in nav and list tiles · 26–28 for the single decorative glyph in a dialog. Stroke 2 (2.25 when a glyph sits on a coloured fill).
- **Outline only.** No filled glyphs, no duotone, no icon-only alarm marks.
- **Tinted tiles.** List and insight icons sit in a 42–46px tile with a soft tint from the status ramp (`--sky-50`, `--mint-50`, `--amber-50`, `--clay-50`) and the matching 600 ink.
- **The Moirai glyph vocabulary:** `heart-pulse` (heart age) · `footprints` (movement) · `moon` (sleep) · `droplets` (blood pressure) · `apple` (diet) · `wine` (alcohol) · `cigarette` / `cigarette-off` · `sliders-horizontal` (simulate) · `sprout` (habits) · `sun` (today) · `user-round` (you) · `sparkles` (insight) · `shield-check` (privacy) · `heart-handshake` (care and support — this is the glyph that replaces a warning triangle) · `trending-down` (improvement, because down is good for most Moirai metrics).
- **No emoji, ever.** No unicode characters used as icons (no ✓, →, •) — use `check`, `arrow-right`, and real spacing instead.
- Specimen: `guidelines/iconography.html`.

---

## Index

**Root**
- `styles.css` — the single entry point consumers link. `@import` lines only.
- `readme.md` — this file.
- `SKILL.md` — Agent-Skills wrapper so this folder works as a downloadable skill.
- `thumbnail.html` — homepage tile.
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `radius.css`, `elevation.css`, `motion.css`, `base.css`.
- `assets/` — README explaining what's missing and what to send. **No logo, no fonts, no imagery were provided.**
- `guidelines/` — 23 specimen cards: colour ramps (sky, mint, amber, clay, neutrals, status ramp, surfaces, gradients), type (numerals, display, body, mono, substitution notice), spacing (scale, layout rhythm, touch targets, radii, elevation, motion, interaction states), brand (iconography, wordmark placeholder, voice).

**Components** (`components/<group>/`, each with `.jsx`, `.d.ts`, `.prompt.md`, and one `@dsCard` HTML per group)
- `core/` — **Icon**, **Button**, **IconButton**, **Card**, **Badge**, **Tag**
- `forms/` — **Input**, **Select**, **Checkbox**, **Radio**, **Switch**, **RangeSlider**
- `navigation/` — **TopAppBar**, **BottomNav**, **Tabs**, **ListRow**
- `feedback/` — **BottomSheet**, **Dialog**, **Toast**, **Notice**, **Tooltip**
- `health/` — **BigStat**, **ProgressRing**, **RiskMeter**, **TrendSpark**, **InsightCard**, **MascotStage**

**Intentional additions** (no source defined a component inventory, so the standard set was authored, plus these, which the brief requires):
- **BigStat** — the brief's "big numbers, for anyone to understand" needs a single owner of numeral scale, count-up and caption.
- **RiskMeter** — a four-band scale with a mandatory `comparison` sentence: the safe way to show a position without a verdict.
- **ProgressRing**, **TrendSpark** — daily goals and direction-only trends.
- **InsightCard** — the "what if → pay-off" unit the simulation product is built around.
- **MascotStage** — the brief's three.js mascot, as a component with a documented `src` slot for the real model.
- **Notice** — inline, tinted, in-flow messaging; the system needs one because bad news must never arrive as a toast.
- **ListRow** — grouped metric/settings rows appear on four of five screens.
- **Icon** — wrapper for the substituted Lucide set.

**UI kit**
- `ui_kits/android_app/` — click-through recreation of the app: onboarding, Today, Simulate, Outlook, Habits, You. Open `index.html`; see that folder's README for what to try.

**Templates** (what consuming projects can start a new design from)
- `templates/app-screen/AppScreen.dc.html` — **Moirai app screen**: phone frame, frosted app bar, hero number with the mascot, insight cards, bottom nav. Editable props: screen title, subtitle, heart age.

## Naming note

The compiled runtime namespace is still `EvaraHealthDesignSystem_a5caa1` (it derives from the project title, which was set before the rename and can only be changed from the project menu). Rename the project to "Moirai Design System" if you want the namespace to match; every card and kit reference will need the new name at the same time. Nothing user-facing carries the old name.

## Caveats
- No slide template was provided, so no sample slides exist.
- Fonts, icons and the mascot model are all stand-ins — replacing them is the first job if real assets exist.
- The system is light-mode only; no dark theme was specified.
- All UI copy is Colombian Spanish (`usted`, no slang). If the app ships in other markets, the numeral formatting (`8.240` / `6,4`) and the `a. m.`/`p. m.` convention are the first things to re-check.
- The mascot is now called **Moira** — a derivation from Moirai. If the mascot has its own approved name, tell me and I'll rename it everywhere.
